# NIGHTWATCH TV

Independent, safety-first Android TV / compatible Fire TV launcher starter.

## Current status
Version 0.2.0 source includes a TV-friendly dashboard, app discovery/filtering, read-only memory and data-storage snapshots, and system settings shortcuts. It is not yet a compiled or device-tested APK.

## Safety scope
- No root access.
- No automatic package disabling or uninstalling.
- No background cleaner or boot receiver.
- The app displays read-only diagnostics and opens supported system settings.
- Launcher selection is left to the user and operating system.
- Android APK compatibility does not extend to Fire TV devices running Vega OS.

## Build
Open this folder in Android Studio with Android SDK installed. Use JDK 17 and Android Gradle Plugin 8.7.3 / Gradle 8.9. Select the `app` run configuration and build the debug APK for a compatible Android TV device.

## Project separation
This repository contains only NIGHTWATCH TV starter files. It does not depend on or modify any other project.
