package tv.nightwatch

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 11, 19)
    private val panel = Color.rgb(16, 27, 43)
    private val cyan = Color.rgb(93, 225, 255)
    private val white = Color.rgb(235, 245, 255)
    private val muted = Color.rgb(151, 176, 198)
    private lateinit var page: LinearLayout
    private lateinit var appListContainer: LinearLayout
    private var allApps: List<LaunchableApp> = emptyList()

    private data class LaunchableApp(
        val label: String,
        val packageName: String,
        val intent: Intent
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        allApps = queryLaunchableApps()
        buildDashboard()
    }

    override fun onResume() {
        super.onResume()
        if (::appListContainer.isInitialized) {
            allApps = queryLaunchableApps()
            renderApps("")
        }
    }

    private fun buildDashboard() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(26), dp(24), dp(26), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(bg, Color.rgb(10, 20, 35), bg)
            )
        }
        scroll.addView(page)
        page.addView(label("N I G H T W A T C H", 12, cyan, true))
        page.addView(label("TV COMMAND CENTRE", 28, white, true).apply {
            setPadding(0, dp(8), 0, dp(4))
        })
        page.addView(label("LIGHTWEIGHT  •  LOCAL  •  REVERSIBLE", 12, muted, false))
        page.addView(space(22))
        page.addView(section("SYSTEM STATUS"))
        page.addView(card("SAFE MODE", "No root access • No automatic system changes • No background cleaner"))
        page.addView(card("MEMORY SNAPSHOT", memorySummary()).apply {
            layoutParams = verticalMargins(0, 8, 0, 0)
        })
        page.addView(card("STORAGE SNAPSHOT", storageSummary()).apply {
            layoutParams = verticalMargins(0, 8, 0, 0)
        })
        page.addView(space(16))
        page.addView(section("QUICK CONTROLS"))
        page.addView(actionButton("OPEN WI-FI SETTINGS", "Uses the device's own settings") {
            openSettings(Intent(Settings.ACTION_WIFI_SETTINGS))
        })
        page.addView(actionButton("OPEN BLUETOOTH SETTINGS", "Direct toggling depends on OS permissions") {
            openSettings(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        })
        page.addView(actionButton("OPEN DEVICE SETTINGS", "System-managed controls") {
            openSettings(Intent(Settings.ACTION_SETTINGS))
        })
        page.addView(actionButton("APP MANAGEMENT", "Open system app and storage management") {
            openSettings(Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS))
        })
        page.addView(space(16))
        page.addView(section("APP LAUNCHER"))
        page.addView(label("Select an app to launch it. NIGHTWATCH does not uninstall or disable apps.", 12, muted, false))
        val search = EditText(this).apply {
            hint = "Filter apps"
            setSingleLine(true)
            textSize = 15f
            setTextColor(white)
            setHintTextColor(muted)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(panel, 10, Color.rgb(34, 67, 91))
            isFocusable = true
            isFocusableInTouchMode = true
        }
        page.addView(search, verticalMargins(0, 10, 0, 10))
        appListContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(appListContainer)
        search.addTextChangedListener(SimpleTextWatcher { renderApps(it) })
        renderApps("")
        page.addView(space(18))
        page.addView(section("SAFETY"))
        page.addView(card("REVERSIBLE BY DESIGN", "NIGHTWATCH only changes its own interface. Selecting another launcher is controlled by the device. This version does not modify system packages or other apps' data."))
        page.addView(space(14))
        page.addView(label("NIGHTWATCH TV  •  BUILD 0.2.0", 11, muted, false))
        setContentView(scroll)
        // Leave focus on the first app action for TV remotes; do not pop up the text keyboard on launch.
        appListContainer.getChildAt(0)?.requestFocus()
    }

    private fun queryLaunchableApps(): List<LaunchableApp> {
        val intents = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        )
        val found = linkedMapOf<String, LaunchableApp>()
        for (intent in intents) {
            val resolved = try {
                if (Build.VERSION.SDK_INT >= 33) {
                    packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    packageManager.queryIntentActivities(intent, 0)
                }
            } catch (_: Exception) { emptyList() }
            for (info in resolved) {
                val appInfo = info.activityInfo?.applicationInfo ?: continue
                if (appInfo.packageName == packageName) continue
                val name = try { info.loadLabel(packageManager)?.toString() ?: appInfo.packageName }
                           catch (_: Exception) { appInfo.packageName }
                val launch = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(if (intent.hasCategory(Intent.CATEGORY_LEANBACK_LAUNCHER))
                        Intent.CATEGORY_LEANBACK_LAUNCHER else Intent.CATEGORY_LAUNCHER)
                    setClassName(appInfo.packageName, info.activityInfo.name)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                found[appInfo.packageName + "/" + info.activityInfo.name] =
                    LaunchableApp(name, appInfo.packageName, launch)
            }
        }
        return found.values.sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun renderApps(filter: String) {
        if (!::appListContainer.isInitialized) return
        appListContainer.removeAllViews()
        val normalized = filter.trim().lowercase(Locale.getDefault())
        val filtered = allApps.filter {
            it.label.lowercase(Locale.getDefault()).contains(normalized) ||
            it.packageName.lowercase(Locale.getDefault()).contains(normalized)
        }
        if (filtered.isEmpty()) {
            appListContainer.addView(card("NO APPS FOUND", "Try another search, or check app visibility on the device."))
            return
        }
        for (app in filtered) {
            appListContainer.addView(actionButton(app.label.uppercase(Locale.getDefault()), app.packageName) {
                try { startActivity(app.intent) }
                catch (_: Exception) {
                    cardDialog("Unable to launch ${app.label}", "The device may restrict this app's launch intent.")
                }
            })
        }
    }

    private fun memorySummary(): String {
        return try {
            val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            manager.getMemoryInfo(info)
            val total = info.totalMem / (1024L * 1024L)
            val available = info.availMem / (1024L * 1024L)
            "Approx. ${formatMb(available)} available of ${formatMb(total)} total. Android manages memory automatically; this app does not force-stop background apps."
        } catch (_: Exception) {
            "Memory statistics are unavailable on this device."
        }
    }

    private fun storageSummary(): String {
        return try {
            val stat = StatFs(Environment.getDataDirectory().absolutePath)
            val total = stat.totalBytes
            val free = stat.availableBytes
            "Device data storage: ${formatBytes(free)} available of ${formatBytes(total)}. Values are system-reported estimates."
        } catch (_: Exception) {
            "Storage statistics are unavailable on this device."
        }
    }

    private fun formatMb(value: Long) = String.format(Locale.getDefault(), "%.0f MB", value.toDouble())
    private fun formatBytes(value: Long): String {
        val gb = value / (1024.0 * 1024.0 * 1024.0)
        return if (gb >= 1) String.format(Locale.getDefault(), "%.1f GB", gb)
        else String.format(Locale.getDefault(), "%.0f MB", value / (1024.0 * 1024.0))
    }

    private fun cardDialog(title: String, body: String) {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(20))
            setBackgroundColor(bg)
            addView(label(title, 18, white, true))
            addView(label(body, 14, muted, false).apply { setPadding(0, dp(12), 0, dp(16)) })
            addView(actionButton("OK", "Return to NIGHTWATCH") { buildDashboard() })
        }
        setContentView(content)
    }

    private fun section(text: String) = label(text, 13, cyan, true).apply {
        setPadding(0, dp(4), 0, dp(8))
    }

    private fun card(title: String, body: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(panel, 14, Color.rgb(38, 73, 96))
        }
        box.addView(label(title, 15, white, true))
        box.addView(label(body, 12, muted, false).apply { setPadding(0, dp(6), 0, 0) })
        return box
    }

    private fun actionButton(title: String, subtitle: String, action: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(15), dp(12), dp(15), dp(12))
            background = rounded(panel, 12, Color.rgb(34, 67, 91))
            setOnClickListener { action() }
            setOnFocusChangeListener { view, focused ->
                view.background = rounded(
                    if (focused) Color.rgb(22, 49, 69) else panel,
                    12,
                    if (focused) cyan else Color.rgb(34, 67, 91)
                )
            }
        }
        box.addView(label(title, 14, white, true))
        box.addView(label(subtitle, 11, muted, false).apply { setPadding(0, dp(4), 0, 0) })
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(8) }
        box.layoutParams = params
        return box
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD)
                       else Typeface.create("sans-serif", Typeface.NORMAL)
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        }

    private fun rounded(color: Int, radius: Int, stroke: Int) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun verticalMargins(left: Int, top: Int, right: Int, bottom: Int) =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(dp(left), dp(top), dp(right), dp(bottom))
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { }
        }
    }
}
