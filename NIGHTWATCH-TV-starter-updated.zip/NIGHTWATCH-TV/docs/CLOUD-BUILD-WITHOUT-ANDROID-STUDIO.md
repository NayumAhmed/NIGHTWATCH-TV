# Build NIGHTWATCH TV without Android Studio (phone-only route)

This route uses GitHub Actions to build the APK on a cloud runner. No Android Studio or local Android SDK is needed.

## One-time setup

1. In a browser, sign in to GitHub and create a **new, separate repository** named `NIGHTWATCH-TV`. Do not use an existing project repository.
2. Download and extract `NIGHTWATCH-TV-starter.zip` on your phone.
3. Upload the **contents inside the `NIGHTWATCH-TV` folder** to the new repository, preserving the folder structure. In particular, `.github/workflows/android-build.yml` must be at the repository path `.github/workflows/android-build.yml`, not buried in another folder.
4. Open the repository's **Actions** tab. If GitHub asks to enable Actions, enable it.
5. Push/commit the files. The workflow starts automatically on a push to `main`; it can also be started from Actions if `workflow_dispatch` is available.
6. Open the workflow run and wait for the **green success** status. Open the completed run, find **Artifacts**, and download `NIGHTWATCH-TV-debug-apk`. Extract the artifact ZIP to get `app-debug.apk`.
7. Transfer `app-debug.apk` to the Android TV/Fire TV Stick and install it. You may need to allow installation from the file manager or downloader you use. Only install on Android-based Fire TV; Amazon Vega OS does not run Android APKs.

## What success means

- A green workflow means the source compiled into a debug APK. It does **not** prove real-device compatibility.
- Test app launch, D-pad navigation, app launching, settings shortcuts, and uninstall/return-to-home behavior on your actual TV before relying on it.
- The app does not root the device, force-stop other apps, or automatically disable system packages.

## If the build fails

Open the failed GitHub Actions run, expand the failed step, and copy the first meaningful compiler/build error. Do not install an APK from a failed or incomplete run.
