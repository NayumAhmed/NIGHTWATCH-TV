# Roadmap

## v0.2.0 — launcher foundation (source implemented; device test pending)
- [x] Independent project identity (`tv.nightwatch`)
- [x] TV-oriented dark dashboard
- [x] Focusable remote-friendly quick actions
- [x] Wi-Fi, Bluetooth, device settings and app management shortcuts
- [x] Launchable app discovery with filter
- [x] Read-only system memory and data-storage snapshots
- [x] No root, background cleaner or package modification

## v0.3.0 — quality and compatibility
- [ ] Build with Android Studio / Gradle
- [ ] Install and test on Android TV hardware
- [ ] Install and test on Android-based Fire TV hardware
- [ ] Verify focus navigation, app launches, settings intents and resume behavior
- [ ] Verify launcher selection and uninstall recovery

## v0.4.0 — app library improvements
- [ ] Favorites and locally stored visibility preferences
- [ ] App details and app-specific settings shortcuts
- [ ] Accessibility review for remote and large-screen use

## v0.5.0 — optional maintenance companion
- [ ] Read-only package inventory
- [ ] Device and OS identification
- [ ] Explicit package-by-package confirmation
- [ ] Exported restore manifest
- [ ] Never automatically disable critical packages

## Release gate
- [ ] Test on physical Android TV and Android-based Fire TV hardware
- [ ] Measure idle and interaction memory use
- [ ] Verify uninstall and original launcher recovery
- [ ] Sign release APK and publish checksum
