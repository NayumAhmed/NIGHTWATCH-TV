# NIGHTWATCH TV safety policy

1. The primary APK must never request root access.
2. Do not disable or uninstall packages automatically.
3. Do not claim to clear RAM by force-killing background applications.
4. Do not clear other applications' data without an explicit system-mediated user action.
5. Do not run a persistent cleaner, overlay or boot receiver in the initial release.
6. Package disabling belongs in a separate optional ADB companion, with device-specific allowlists and a recorded restore plan.
7. Never disable Settings, package installer, system update, connectivity or the original launcher as part of a generic preset.
8. Explain that uninstalling the APK does not undo independent ADB changes.
9. Check device OS before installation; Android APKs do not run on Vega OS.
10. Test on real hardware before describing a build as compatible or safe for a particular model.
