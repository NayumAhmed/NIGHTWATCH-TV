#!/usr/bin/env python3
"""Fast source sanity checks; these do not replace an Android build or device test."""
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ET.parse(ROOT / "app/src/main/AndroidManifest.xml")
ET.parse(ROOT / "app/src/main/res/values/styles.xml")

manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text()
gradle = (ROOT / "app/build.gradle.kts").read_text()
activity = (ROOT / "app/src/main/java/tv/nightwatch/MainActivity.kt").read_text()
watcher = (ROOT / "app/src/main/java/tv/nightwatch/SimpleTextWatcher.kt").read_text()

assert "tv.nightwatch" in gradle
assert "QUERY_ALL_PACKAGES" not in manifest
assert "android.permission.INTERNET" not in manifest
assert "android.permission.WRITE_SETTINGS" not in manifest
assert "queryLaunchableApps" in activity
assert "memorySummary" in activity and "storageSummary" in activity
assert "ACTION_WIFI_SETTINGS" in activity
assert "ACTION_BLUETOOTH_SETTINGS" in activity
assert "ACTION_MANAGE_APPLICATIONS_SETTINGS" in activity
assert "forceStopPackage" not in activity
assert "pm disable" not in activity.lower()
assert "TextWatcher" in watcher and "onValueChanged" in watcher

print("PASS: XML syntax")
print("PASS: independent application identity")
print("PASS: no Internet, broad package-visibility, or write-settings permission")
print("PASS: app discovery, diagnostics, and settings shortcuts present")
print("PASS: no force-stop or package-disable implementation")
print("PASS: filter text watcher present")
print("NOTE: Android compilation and hardware behavior must still be tested on an Android SDK/device.")
